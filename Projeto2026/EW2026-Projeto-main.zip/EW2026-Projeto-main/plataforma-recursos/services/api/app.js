const express = require('express')
const mongoose = require('mongoose')
const { randomUUID } = require('crypto')
const fsp = require('fs/promises')
const swaggerUi = require('swagger-ui-express')
const YAML = require('yamljs')
const cookieParser = require('cookie-parser')
const helmet = require('helmet')

const routes = require('./routes')
const { config } = require('./lib/config')
const { jsonError } = require('./lib/http')
const { initSystemNewsTriggers } = require('./jobs/systemNews')
const { auditHttpRequests } = require('./audit')
const { explicitCors } = require('./middleware/cors')
const { rateLimitApi } = require('./middleware/rateLimit')
const swaggerDocument = YAML.load('./swagger.yaml')

const app = express()

app.use(
	helmet({
		contentSecurityPolicy: {
			directives: {
				defaultSrc: ["'self'"],
				scriptSrc: ["'self'", "'unsafe-inline'", 'unpkg.com', 'cdn.jsdelivr.net'],
				styleSrc: ["'self'", "'unsafe-inline'", 'unpkg.com', 'cdn.jsdelivr.net'],
				imgSrc: ["'self'", 'data:'],
				connectSrc: ["'self'"],
			},
		},
	})
)

app.use(explicitCors)
app.use(express.json({ limit: config.dataTransfer.jsonBodyLimit }))
app.use(cookieParser())

app.use((req, res, next) => {
	const requestId = req.headers['x-request-id'] || randomUUID()
	req.requestId = requestId
	res.locals.requestId = requestId
	res.setHeader('X-Request-Id', requestId)
	next()
})

app.use((req, res, next) => {
	const d = new Date().toISOString().substring(0, 16)
	console.log(`[api] ${req.method} ${req.url} ${d} [${req.requestId}]`)
	next()
})

app.use(rateLimitApi)
app.use(auditHttpRequests)
app.use('/api', routes)
app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument))
app.get('/api/openapi.json', (req, res) => {
	res.json(swaggerDocument)
})

app.use((req, res) => {
	jsonError(res, 404, { code: 'NOT_FOUND', message: 'rota não encontrada' })
})

app.use((err, req, res, next) => {
	console.error(`[api] unexpected error [${req.requestId || '-'}]:`, err)
	jsonError(res, err?.status || 500, {
		code: err?.code || 'INTERNAL_ERROR',
		message: err?.message || 'erro interno',
	})
})

async function start() {
	try {
		await fsp.mkdir(config.storage.aipDir, { recursive: true })
		await mongoose.connect(config.mongoUrl)
		console.log('MongoDB: connected')

		app.listen(config.port, () => {
			console.log(`API listening on port ${config.port}`)
			initSystemNewsTriggers()
		})
	} catch (err) {
		console.error('API startup error:', err)
		process.exit(1)
	}
}

start()
